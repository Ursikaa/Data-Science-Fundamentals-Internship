# Data Science Tool Mastery Project — Wine Classification

## Overview
An integrated portfolio project demonstrating practical use of NumPy, Pandas, Matplotlib, Seaborn and Scikit-learn.

## Dataset
- Samples: 178
- Features: 13
- Classes: 3
- Task: Multiclass classification
- Source: scikit-learn Wine dataset

## Tools Demonstrated
- NumPy: arrays, mean, standard deviation, vectorized standardization
- Pandas: inspection, filtering, grouping, aggregation, descriptive statistics
- Matplotlib: figures, labels, saving plots
- Seaborn: countplot, histplot, scatterplot, heatmap
- Scikit-learn: train/test split, StandardScaler, Pipeline, Logistic Regression, Random Forest, metrics and cross-validation

## Model Results
- Random Forest: Accuracy 1.000, Precision 1.000, Recall 1.000, F1 1.000\n- Logistic Regression: Accuracy 0.972, Precision 0.974, Recall 0.972, F1 0.972\n
Best fixed-split model: **Random Forest**

### Five-Fold Cross-Validation
- Accuracy: 0.983
- Precision: 0.984
- Recall: 0.983
- F1: 0.983

## Files
`data_science_tool_mastery.ipynb` • `wine_dataset.csv` • `Data_Science_Tool_Mastery_Report.docx` • `README.md` • `requirements.txt` • `figures/`

## Run
```bash
pip install -r requirements.txt
```
Open the notebook in Jupyter Notebook/JupyterLab.

## Dataset Documentation
https://scikit-learn.org/stable/datasets/toy_dataset.html#wine-dataset

## Author
Monika — B.Tech CSE (AI/ML)
