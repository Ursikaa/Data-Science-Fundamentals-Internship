# Real-World Dataset Analysis — Diabetes Disease Progression

## Project overview
This project performs a complete real-world dataset analysis using the scikit-learn Diabetes dataset. It includes data exploration, quality checks, descriptive statistics, visualization, correlation analysis, and predictive regression modeling.

### Dataset
- 442 observations
- 10 numeric predictor variables
- 1 quantitative target: disease progression one year after baseline
- Source: scikit-learn dataset documentation
- Original source information is documented by scikit-learn.

## Analysis performed
1. Dataset structure and data types
2. Missing-value and duplicate checks
3. IQR-based outlier screening
4. Descriptive statistics
5. Target distribution
6. Correlation heatmap and target correlations
7. BMI vs target relationship
8. Multiple regression models
9. Model evaluation using MAE, RMSE and R²
10. Five-fold cross-validation
11. Actual-vs-predicted and residual diagnostics
12. Feature importance

## Main results
Best test-set model: **Gradient Boosting**

- Test MAE: **42.41**
- Test RMSE: **52.31**
- Test R²: **0.484**
- 5-fold CV mean R²: **0.460**
- 5-fold CV mean MAE: **45.62**
- 5-fold CV mean RMSE: **55.96**

## Important interpretation
The strongest simple Pearson associations with the target are BMI (r=0.586), s5 (r=0.566), bp (r=0.441), s3 (r=-0.395, negative), and s6 (r=0.382). These are associations, not causal effects.

## Files
- `real_world_dataset_analysis.ipynb` — complete notebook
- `diabetes_dataset.csv` — dataset used
- `figures/` — visualizations
- `Real_World_Dataset_Analysis_Report.docx` — submission-ready report
- `README.md` — project documentation
- `requirements.txt` — Python packages

## Reproducibility
Random states are fixed at 42 for train/test splitting and model reproducibility.
